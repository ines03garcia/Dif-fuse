import torch
import torchvision
from denoising_diffusion_pytorch import Unet, GaussianDiffusion
from collections import OrderedDict

# Load the state_dict
state_dict = torch.load('/home/csantiago/models/model007000.pt', map_location='cuda')

# Remove 'module.' prefix
new_state_dict = OrderedDict()
for k, v in state_dict.items():
    name = k.replace('module.', '')  # strip 'module.'
    new_state_dict[name] = v

model = Unet(
    dim=128,
    dim_mults=(1, 1, 2, 2, 4, 4),  
    channels=1
)

# Load the modified state_dict
model.load_state_dict(new_state_dict, strict=False)
model.eval()

diffusion = GaussianDiffusion(
    model,
    image_size=256,
    timesteps=1000,
    sampling_timesteps=1000
)

# Sample images
sampled_images = diffusion.sample(batch_size=1)  # generate 4 images

# Save the results
torchvision.utils.save_image(sampled_images, 'samples.png', nrow=2)
